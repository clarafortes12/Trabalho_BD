-- Autores: 
--     Lucas Gabriel de Oliveira Gurgel - 19/0121637 
--     Maria Clara Oliveira Fortes - 19/0017503

USE hospital;

CALL mostrar_enfermeiro();
CALL mostrar_medico();
CALL mostrar_convenio('11111111111111');
CALL mostrar_pacientes_medico('00000FF');
CALL mostrar_exames_pacientes(2);
CALL mostrar_laboratorios_hospital('22222222222222');
CALL mostrar_exame_laboratorio(1);
