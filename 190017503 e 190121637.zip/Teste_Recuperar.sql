-- Autores: 
--     Lucas Gabriel de Oliveira Gurgel - 19/0121637 
--     Maria Clara Oliveira Fortes - 19/0017503

call recuperar_uf(1);
call recuperar_uf(2);
call recuperar_uf(3);
call recuperar_uf(4);
call recuperar_uf(5);

call recuperar_cidade(1);
call recuperar_cidade(2);
call recuperar_cidade(3);
call recuperar_cidade(4);
call recuperar_cidade(5);

call recuperar_bairro(1);
call recuperar_bairro(2);
call recuperar_bairro(3);
call recuperar_bairro(4);
call recuperar_bairro(5);

call recuperar_tipo_endereco(1);
call recuperar_endereco(1);
call recuperar_hospital('11111111111111');
call recuperar_ala(1);
call recuperar_tipo_telefone(1);
call recuperar_tipo_convenio(1);
call recuperar_sexo(1);
call recuperar_plano_saude(1);
call recuperar_estado_civil(1);
call recuperar_telefone(1);
call recuperar_enfermaria(1);
call recuperar_laboratorio(1);
call recuperar_convenio(1);
call recuperar_equipamento(1);
call recuperar_pessoa('03503503555');
call recuperar_paciente(1);
call recuperar_funcionario(1);
call recuperar_dependente(1);
call recuperar_medico('00000FF');
call recuperar_enfermeiro('00000FK');
call recuperar_consulta(1);
call recuperar_receita(1);
call recuperar_exame(1);
call recuperar_remedio(1);